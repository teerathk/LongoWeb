
Email test


<?php

if(mail('jseplak@gmail.com', 'test email', 'this is the email message')){

	print "Message Sent";
}
else{
	print "Message Not Sent";
}

?>