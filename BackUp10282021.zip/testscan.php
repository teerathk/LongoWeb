<html>
	
	<head>
		
	</head>
	<body>
		<a href="http://www.longocorporation.com/log?location=999&pass=Ut6l9b2d7rtfoB7sF">
			Click here to test qr code
		</a>
	</body>
</html>