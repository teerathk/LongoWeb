<?php

//  Database connection 1
$host = "p3plcpnl1192.prod.phx3.secureserver.net";
$user = 'longoqrapp';
$password = 'Abcd@1234';
$database = 'longoqrapp';

$mysqli = new mysqli($host, $user, $password, $database);

// Check connection
if ($mysqli->connect_errno) {
    echo "Failed to connect to MySQL: " . $mysqli->connect_error;
    exit();
}

function connection($host = 'p3plcpnl1192.prod.phx3.secureserver.net', $user = 'longoqrapp', $password = 'Abcd@1234', $database = 'longoqrapp')
{
    $mysqli = new mysqli($host, $user, $password, $database);

    // Check connection
    if ($mysqli->connect_errno) {
        echo "Failed to connect to MySQL: " . $mysqli->connect_error;
        exit();
    }
    return $mysqli;
}