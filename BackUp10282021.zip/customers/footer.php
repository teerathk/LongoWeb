<?php
/**
 * Created by Mustafeez Ali (mtfz@msn.com).
 * Date: 5/2/2017
 * Time: 11:10 PM
 */
?>

<script src="<?php echo $baseLoc ?>/js/jquery.easing.1.3.js"></script>
<script src="<?php echo $baseLoc ?>/js/tms-0.4.x.js"></script>

<script src="<?php echo $baseLoc ?>/js/bootstrap.min.js"></script>
<script src="<?php echo $baseLoc ?>/js/jquery.mask.js"></script>

<script src="<?php echo $baseLoc ?>/js/plego.js"></script>

<footer>
    <p>© 2013 Longo Corporation</p>
</footer>

</div>
</body>
</html>
