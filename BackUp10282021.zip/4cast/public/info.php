<?php
    include '../php/template.php';
    $title = "4Cast Realty Group - Home Page";
    $keywords = "";
    $description = "";
    printHead($title, $keywords, $description);
?>

						<article class="col1">
							<div class="pad2">
								<h2 class="pad_bot1 pad_top1">It’s more than sell a house buy a house</h2>
								<br/>
								<br/>
                                                                <p>
                                                                    We've surrounded ourselves with industry professionals to assist you with the many aspects involved in a real estate transaction. Whether it’s an attorney, a financial advisor, a home inspector or a financial institution, we can refer you to people who are experts in their fields. Don’t hesitate to advise us of your special needs. Our objective is to assure you’re getting the proper guidance when and where you need it.
                                                                </p>
                                                                <br />
                                                                <br />
                                                                <br />
                                                                <br />
                                                                <br />
                                                                <br />
                                                                <br />
                                                                <br />
                                                        </div>
						</article>
						
					</div>
					
				</section>
			</div>
		</div>
<?php
printFooter();
?>