<?php
    include '../php/template.php';
    $title = "4Cast Realty Group - Home Page";
    $keywords = "";
    $description = "";
    printHead($title, $keywords, $description);
?>

 
                        <article class="col1" style="margin-left: 130px;">
                            <div id="slider">
                                <img src="images/_downtown.jpg" title="<strong></strong>" alt="" title="<span><a href='#'></a></span>">
                                <img src="images/_chiCondoInside1.jpg" alt="" title="<strong></strong>" title="<span><a href='#'></a></span>">
                                <img src="images/img3.jpg" alt="" title="<strong></strong>" title="<span><a href='#'></a></span>">
                                <img src="images/img6.jpg" alt="" title="<strong></strong>" title="<span><a href='#'></a></span>">
                                
                            </div>
                        </article>

                    </div>
                    <div class="wrapper">
                        <article class="col1">
                            <div class="pad_left1">
                                <h2 class="pad_bot1">*Innovation   *Direction   *Solutions</h2>
                                <br/>
                                <br/>
                                <div class="wrapper">
                                    <p>
                                       At 4cast realty group we strongly believe in providing not only basic real estate services but a foundation for financial growth. We have taken our business experiences and created an environment that nurtures this growth.  We have bought and sold residential and commercial property’s, been landlords and silent partners, used 1031 exchanges to avoid tax penalties and bought and sold businesses of our own. With this experience and our network of professionals we will give you a unique perspective on your real estate transactions.
                                    </p>
                                </div>
                                
                            </div>
                        </article>
                        <article class="col2">

                        </article>
                    </div>
                </section>
            </div>
        </div>

 <?php
 printFooter();
 ?>