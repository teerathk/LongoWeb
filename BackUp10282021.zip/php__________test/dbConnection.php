<?php
if(!defined('APP')) die();

//  Database connection 1
$GLOBALS['dbHost'] = "p3plcpnl1192.prod.phx3.secureserver.net";
$GLOBALS['dbUserName'] = 'longoqrapp';
$GLOBALS['dbPassword'] = 'Abcd@1234';
$GLOBALS['dbName'] = 'longoqrapp';
$GLOBALS['adminEmail'] = 'longocorporation@gmail.com';

?>