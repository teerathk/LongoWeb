<?php

if(!defined('APP')) die();



//  Database connection 1

$GLOBALS['dbHost'] = "localhost";//"p3plcpnl1192.prod.phx3.secureserver.net";

$GLOBALS['dbUserName'] = "root"; //'longoqrapp';

$GLOBALS['dbPassword'] = ""; //'Abcd@1234';

$GLOBALS['dbName'] = "longoqrapp";// 'longoqrapp';

$GLOBALS['adminEmail'] = 'longocorporation@gmail.com';

?>